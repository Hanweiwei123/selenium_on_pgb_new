alert("abc");
navigator.system.get("Network",success,null);
alert("bc");
function success(connection) {
alert("TEST");
  if (connection.type===connection.TYPE_IEEE802_11)
    navigator.system.watch("WifiConnection",wifiWatchCB);
}

function wifiWatchCB(connection) {
  //document.getElementById(indicator, "Wireless "+connection.essid+" at "+(connection.signalStrength*100)+"%");
  //cosole.log("Wireless "+connection.essid+" at "+(connection.signalStrength*100)+"%");
  alert("Wireless "+connection.essid+" at "+(connection.signalStrength*100)+"%");

}